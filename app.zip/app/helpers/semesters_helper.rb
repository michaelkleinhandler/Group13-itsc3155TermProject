module SemestersHelper
end

class Teacher < ApplicationRecord
end

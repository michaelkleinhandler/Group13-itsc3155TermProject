class Student < ApplicationRecord
  has_many :courses
end
